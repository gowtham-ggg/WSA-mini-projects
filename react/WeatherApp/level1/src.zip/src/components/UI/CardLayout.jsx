import React from 'react'

const CardLayout = ({children}) => {
  return (
    <div className='card-container'>
      {children}
    </div>
  )
}

export default CardLayout
